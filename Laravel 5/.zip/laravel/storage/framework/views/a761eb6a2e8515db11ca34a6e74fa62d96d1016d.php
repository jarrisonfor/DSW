 <?php $__env->startSection('contenido'); ?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<table class="ui celled table">
	
	<thead>
		<tr>
			<th class="center aligned">id</th>
			<th class="center aligned">nombre</th>
			<th class="center aligned">precio unidad</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $ut5_7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td class="center aligned"><?php echo e($i->id); ?></td>
			<td class="center aligned"><?php echo e($i->producto); ?></td>
			<td class="center aligned"><?php echo e($i->precio_unidad); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/2019-ASI2-IMW/laravel/resources/views/UT5_7/index.blade.php ENDPATH**/ ?>