<?php $__env->startSection('contenido'); ?>
<h1>
	Insertar
</h1>
<form class="ui form" action="<?php echo e(url('UT5_2')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="field">
        <label>empresa</label>
        <input type="text" name="NombreCompañía" placeholder="empresa">
    </div>
	
	<div class="field">
        <label>Contacto</label>
        <input type="text" name="NombreContacto" placeholder="NombreContacto">
    </div>
	
    <div class="field">
        <label>direccion</label>
        <input type="text" name="Dirección" placeholder="direccion">
    </div>
    <div class="field">
        <label>ciudad</label>
        <input type="text" name="Ciudad" placeholder="ciudad">
    </div>
    <div class="field">
        <label>pais</label>
        <input type="text" name="País" placeholder="pais">
    </div>
    <div class="field">
        <label>lat</label>
        <input type="text" name="Latitud" placeholder="lat">
    </div>
    <div class="field">
        <label>lng</label>
        <input type="text" name="Longitud" placeholder="lng">
    </div>
    <button type="submit" id="insertar" class="ui button primary green">
        <i class="icon save"></i>
        Guardar
    </button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/2019-ASI2-IMW/laravel/resources/views/UT5_2/create.blade.php ENDPATH**/ ?>