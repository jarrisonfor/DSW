<?php

use Illuminate\Http\Request;

Route::get('UT5_2/{UT5_2}/contacto', 'UT5_2Controller@contacto');