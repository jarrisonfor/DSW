<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UT5_2 extends Model
{
    protected $table = 'UT5_2';
    protected $guarded = [];
    protected $primaryKey = 'IdProveedor';
    public $timestamps = false;
}
