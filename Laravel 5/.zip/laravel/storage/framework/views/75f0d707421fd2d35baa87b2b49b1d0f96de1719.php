 <?php $__env->startSection('contenido'); ?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<style>
	nav {
		display: inline-block;
	}

	.cabecera {
		display: flex;
		justify-content: space-between;
	}
</style>
<div class='cabecera'>

	<a href="UT5_2/create">
		<button id="insertar" class="ui button primary green">
			<i class="icon add"></i>
			Insertar
		</button>
	</a>
	<?php echo e($ut5_2->links()); ?>

</div>
<table class="ui celled table">
	<thead>
		<tr>
			<th class="center aligned">empresa</th>
			<th class="center aligned">Contacto</th>
			<th class="center aligned">direccion</th>
			<th class="center aligned">ciudad</th>
			<th class="center aligned">pais</th>
			<th class="center aligned">PDF</th>
			<th class="center aligned">ver</th>
			<th class="center aligned">editar</th>
			<th class="center aligned">borrar</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $ut5_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td class="center aligned">
				<a href="<?php echo e(url('UT5_2')); ?>/<?php echo e($i->IdProveedor); ?>/productos"><?php echo e($i->NombreCompañía); ?></a>
			</td>
			<td class="center aligned" data-id="<?php echo e($i->IdProveedor); ?>">
				<span class="contacto"><?php echo e($i->NombreContacto); ?></span>
			</td>
			<td class="center aligned"><?php echo e($i->Dirección); ?></td>
			<td class="center aligned"><?php echo e($i->Ciudad); ?></td>
			<td class="center aligned"><?php echo e($i->País); ?></td>
			<td class="center aligned">
				<form action="<?php echo e(url('UT5_2')); ?>/<?php echo e($i->IdProveedor); ?>/pdf" method='GET'>
					<?php echo csrf_field(); ?>
					<i class="file pdf outline icon"></i>
				</form>
			</td>
			<td class="center aligned">
				<form action="<?php echo e(url('UT5_2')); ?>/<?php echo e($i->IdProveedor); ?>" method='GET'>
					<?php echo csrf_field(); ?>
					<i class="eye icon"></i>
				</form>
			</td>
			<td class="center aligned">
				<form action="<?php echo e(url('UT5_2')); ?>/<?php echo e($i->IdProveedor); ?>/edit" method='GET'>
					<?php echo csrf_field(); ?>
					<i class="edit icon"></i>
				</form>
			</td>
			<td class="center aligned">
				<form action="<?php echo e(url('UT5_2')); ?>/<?php echo e($i->IdProveedor); ?>" method='POST'>
					<?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
					<i class="trash icon"></i>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="ui tiny modal">
	<div class="header">Header</div>
	<div class="content" id="contenidomodal">
	</div>

</div>
<script>
	$(document).ready(function() {
		$("i.icon").click(function() {
			$(this).closest("form").submit();
		});
		$('.contacto').click(function() {
			var id = $(this).closest("td").data();
			console.log(id.id);
			$('.tiny.modal')
				.modal('show');
			$.ajax({
				url: `<?php echo e(url('api/UT5_2')); ?>/${id.id}/contacto`,
				method: 'GET',
				success: function(r) {
					var html = `
						<table class="ui celled table">
	
	<thead>
		<tr>
			<th class="center aligned">id</th>
			<th class="center aligned">nombre</th>
			<th class="center aligned">precio unidad</th>
		</tr>
	</thead>
	<tbody>

					`
					$.each(r, function(index, value) {
						html += `
		<tr>
			<td class="center aligned">${value.id}</td>
			<td class="center aligned">${value.producto}</td>
			<td class="center aligned">${value.precio_unidad}</td>
		</tr>
						`
					});
					html += `
						</tbody>
</table>

					`
					$('#contenidomodal').html(html)
				}
			});
		})
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/2019-ASI2-IMW/laravel/resources/views/UT5_2/index.blade.php ENDPATH**/ ?>