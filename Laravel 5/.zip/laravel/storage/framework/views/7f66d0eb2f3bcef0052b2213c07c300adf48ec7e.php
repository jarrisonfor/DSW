<?php $__env->startSection('contenido'); ?>

<h1>
	Mostrar
</h1>

<table class="ui celled table">
    <thead>
		<tr>
      <th class="center aligned">id</th>
      <th class="center aligned">empresa</th>
      <th class="center aligned">Contacto</th>
      <th class="center aligned">direccion</th>
      <th class="center aligned">ciudad</th>
      <th class="center aligned">pais</th>
      <th class="center aligned">lat</th>
      <th class="center aligned">lng</th>
    </tr>
		</thead>
		<tbody>
            <tr>
                <td class="center aligned"><?php echo e($IdProveedor); ?></td>
                <td class="center aligned"><?php echo e($NombreCompañía); ?></td>
				<td class="center aligned"><?php echo e($NombreContacto); ?></td>
                <td class="center aligned"><?php echo e($Dirección); ?></td>
                <td class="center aligned"><?php echo e($Ciudad); ?></td>
                <td class="center aligned"><?php echo e($País); ?></td>
                <td class="center aligned"><?php echo e($Latitud); ?></td>
                <td class="center aligned"><?php echo e($Longitud); ?></td>
            </tr>
		</tbody>
</table>
<h4>
	Si quieres ver el mapa, escanea el siguiente QR
</h4>
<img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(500)->errorCorrection('H')->merge('https://i.imgur.com/hiuszoF.png', .2, true)->generate(url('UT5_2').'/'.$IdProveedor)); ?> ">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/2019-ASI2-IMW/laravel/resources/views/UT5_2/pdf.blade.php ENDPATH**/ ?>